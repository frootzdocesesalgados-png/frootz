// Configuração do site — pode ser editada no servidor de hospedagem
// sem precisar recompilar a aplicação.
//
// apiUrl: endereço completo do servidor da API (ex: "https://api.sualoja.com.br").
// Deixe vazio ("") se o site estiver hospedado no MESMO domínio do servidor.
window.APP_CONFIG = {
  apiUrl: ""
};
